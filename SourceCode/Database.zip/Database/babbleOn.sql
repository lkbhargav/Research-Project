-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (armv7l)
--
-- Host: localhost    Database: chat
-- ------------------------------------------------------
-- Server version	5.5.44-0+deb8u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `adminId` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `emailID` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`adminId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'Bhargav','lkbhargav','passedoc','lkbhargav9@gmail.com'),(2,'Madhur','bala','password','madhur2k9@gmail.com'),(3,'Amish','naik','password','naikamish0822@gmail.com');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bans`
--

DROP TABLE IF EXISTS `bans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bans` (
  `banID` int(11) NOT NULL AUTO_INCREMENT,
  `groupID` int(11) DEFAULT NULL,
  `userID` int(11) DEFAULT NULL,
  PRIMARY KEY (`banID`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bans`
--

LOCK TABLES `bans` WRITE;
/*!40000 ALTER TABLE `bans` DISABLE KEYS */;
INSERT INTO `bans` VALUES (1,9,28),(2,9,28),(3,9,28),(4,9,28),(5,9,28),(6,9,28),(7,9,28),(8,9,28),(9,9,28),(10,9,28),(11,9,28),(12,9,28),(13,9,28),(14,9,28),(15,9,28),(16,9,28),(17,9,28),(18,10,31),(19,12,28),(20,16,28),(21,4,31),(22,4,31),(23,4,28),(24,6,28);
/*!40000 ALTER TABLE `bans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `codesss`
--

DROP TABLE IF EXISTS `codesss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `codesss` (
  `email` varchar(50) DEFAULT NULL,
  `code` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `codesss`
--

LOCK TABLES `codesss` WRITE;
/*!40000 ALTER TABLE `codesss` DISABLE KEYS */;
INSERT INTO `codesss` VALUES ('lkbhargav@gmail.com','1'),('naikamish0822@gmail.com','1'),('lkbhargav9@gmail.com','1'),('lkbhargav2@gmail.com','1'),('lkbhargav5@gmail.com','1'),('madhur2k9@gmail.com','1'),('hondas@sacredheart.edu','1'),('chandu3267@gmail.com','1'),('naikamish082222222@gmail.com','755639'),('naika@mail.sacredheart.com','202346'),('naikamish0822@gmail.com','1'),('srishamanth@gmail.com','1'),('pratikkshah@hotmail.com','1'),('b@gmail.com','1'),('c@gmail.com','1'),('p@gmail.com','1'),('m@gmail.com','1');
/*!40000 ALTER TABLE `codesss` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contactus`
--

DROP TABLE IF EXISTS `contactus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contactus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `email` varchar(35) DEFAULT NULL,
  `contactNumber` bigint(20) DEFAULT NULL,
  `subject` varchar(50) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `replied` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contactus`
--

LOCK TABLES `contactus` WRITE;
/*!40000 ALTER TABLE `contactus` DISABLE KEYS */;
INSERT INTO `contactus` VALUES (1,'Bhargav','lkbhargav9@gmail.com',12035432147,'Info','This is a small info',1),(2,'Chandrakanth Pentako','chandu3267@gmail.com',12035431239,'King','This is about he king',NULL),(3,'Naveen J','lkbhargav2@gmail.com',18123829559,'Feedback','This is a friendly feedback',1),(4,'Bhargav',NULL,NULL,NULL,NULL,NULL),(5,'Bhargav',NULL,NULL,NULL,NULL,NULL),(6,'Sai Baba',NULL,NULL,NULL,NULL,NULL),(7,'Sai Baba',NULL,NULL,NULL,NULL,NULL),(8,'Sai Baba',NULL,NULL,NULL,NULL,1),(9,'Sai Baba',NULL,NULL,NULL,NULL,NULL),(10,'Sai Baba',NULL,NULL,NULL,NULL,NULL),(11,'Sai Baba',NULL,NULL,NULL,NULL,NULL),(12,'Sai Baba',NULL,NULL,NULL,NULL,NULL),(13,'Chandrakanth Pentako','lkbhargav2@gmail.com',12035431239,'Grade for Assignment 8 ','is the grade out yet',1),(14,'Sai Baba',NULL,NULL,NULL,NULL,NULL),(15,'Sai Baba',NULL,NULL,NULL,NULL,NULL),(16,'Sai Baba',NULL,NULL,NULL,NULL,NULL),(17,'abcd','madhur2k9@gmail.com',13392043986,'nice','bala is awesome',1),(18,'rofl','rofl123@gmail.com',12031234567,'this is amazing','you rock man!',NULL),(19,'','',1,'','',NULL),(20,'Bhargav L K','lkbhargav9@gmail.com',12035432147,'People','Bala is it working.',1),(21,'Bhargav L K','lkbhargav9@gmail.com',12035432147,'call','call me soon',1),(22,'Bhargav ','lkbhargav9@gmail.com',12035432147,'feedback','i like the way it is implemented',NULL),(23,'Bhargav','lkbhargav7@gmail.com',12035432147,'impoprtant','bug',1);
/*!40000 ALTER TABLE `contactus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `downloadVeri`
--

DROP TABLE IF EXISTS `downloadVeri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `downloadVeri` (
  `code` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `downloadVeri`
--

LOCK TABLES `downloadVeri` WRITE;
/*!40000 ALTER TABLE `downloadVeri` DISABLE KEYS */;
INSERT INTO `downloadVeri` VALUES (1050790049),(1),(1026105981),(1192508103),(1039939431);
/*!40000 ALTER TABLE `downloadVeri` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupJoins`
--

DROP TABLE IF EXISTS `groupJoins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groupJoins` (
  `joinID` int(11) NOT NULL AUTO_INCREMENT,
  `groupID` int(11) DEFAULT NULL,
  `userID` int(11) DEFAULT NULL,
  `changeTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`joinID`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupJoins`
--

LOCK TABLES `groupJoins` WRITE;
/*!40000 ALTER TABLE `groupJoins` DISABLE KEYS */;
INSERT INTO `groupJoins` VALUES (1,4,28,'2016-04-20 18:45:28',1),(2,4,28,'2016-04-20 18:45:32',0),(3,4,28,'2016-04-20 19:35:42',1),(4,1,28,'2016-04-20 19:39:03',1),(5,1,28,'2016-04-20 19:39:05',1),(6,1,28,'2016-04-20 19:39:07',0),(7,1,28,'2016-04-20 19:39:11',0),(8,4,31,'2016-04-22 13:26:05',1),(9,4,28,'2016-04-22 13:30:26',1),(10,4,28,'2016-04-22 13:33:45',0),(11,4,28,'2016-04-22 15:58:52',1),(12,4,28,'2016-04-22 15:58:56',0),(13,3,28,'2016-04-22 15:59:12',1),(14,4,28,'2016-04-22 15:59:15',1),(15,4,31,'2016-04-22 16:00:40',1),(16,3,28,'2016-04-22 16:00:59',0),(17,4,28,'2016-04-22 16:00:59',0),(18,4,32,'2016-04-22 16:01:30',1),(19,4,28,'2016-04-22 16:01:42',1),(20,4,31,'2016-04-22 16:03:36',1),(21,4,32,'2016-04-22 16:15:56',0),(22,4,32,'2016-04-22 16:16:25',1),(23,4,28,'2016-04-22 16:17:55',0),(24,4,28,'2016-04-22 16:18:34',1),(25,4,32,'2016-04-22 16:19:59',0),(26,4,31,'2016-04-22 16:22:14',0),(27,4,32,'2016-04-22 16:22:36',1),(28,4,31,'2016-04-22 16:22:56',1),(29,4,28,'2016-04-22 16:24:19',0),(30,4,28,'2016-04-22 16:25:42',1),(31,4,31,'2016-04-22 16:33:10',0),(32,4,31,'2016-04-22 16:33:14',1),(33,4,31,'2016-04-22 16:33:17',0),(34,4,32,'2016-04-22 16:34:57',0),(35,4,32,'2016-04-22 16:35:36',1),(36,4,31,'2016-04-22 22:26:24',1),(37,4,31,'2016-04-22 22:26:52',0),(38,4,31,'2016-04-22 23:17:26',1),(39,3,31,'2016-04-22 23:27:09',1),(40,1,31,'2016-04-22 23:27:11',1),(41,1,31,'2016-04-22 23:27:17',0),(42,3,31,'2016-04-22 23:27:17',0),(43,4,31,'2016-04-22 23:27:17',0),(44,4,28,'2016-04-23 18:20:59',1),(45,4,31,'2016-04-23 18:21:01',1),(46,4,31,'2016-04-23 18:21:07',0),(47,4,31,'2016-04-23 18:21:26',1),(48,4,28,'2016-04-23 18:23:54',0),(49,4,28,'2016-04-23 18:24:09',1),(50,4,28,'2016-04-23 18:26:01',0),(51,4,28,'2016-04-23 18:26:16',1),(52,4,31,'2016-04-23 18:27:04',0),(53,4,31,'2016-04-23 18:38:29',1),(54,4,31,'2016-04-23 18:39:07',0),(55,4,31,'2016-04-23 18:39:26',1),(56,4,31,'2016-04-23 18:40:37',0),(57,4,28,'2016-04-23 18:49:53',0),(58,4,37,'2016-04-26 23:24:29',1),(59,4,37,'2016-04-26 23:24:49',0),(60,4,37,'2016-04-26 23:34:55',1),(61,4,28,'2016-04-26 23:36:36',1),(62,4,31,'2016-04-26 23:39:40',1),(63,4,31,'2016-04-26 23:40:09',0),(64,4,31,'2016-04-26 23:42:28',1),(65,4,28,'2016-04-26 23:42:47',0),(66,4,37,'2016-04-26 23:43:17',0),(67,4,31,'2016-04-26 23:43:31',0),(68,4,31,'2016-04-26 23:43:50',1),(69,4,28,'2016-04-26 23:43:53',1),(70,4,31,'2016-04-26 23:45:55',0),(71,4,28,'2016-04-26 23:46:24',0),(72,4,31,'2016-04-28 00:07:26',1),(73,4,28,'2016-04-28 00:07:34',1),(74,4,28,'2016-04-28 00:11:30',0),(75,3,31,'2016-04-28 00:12:42',1),(76,3,31,'2016-04-28 00:16:15',0),(77,4,31,'2016-04-28 00:16:15',0),(78,5,28,'2016-04-28 00:17:29',1),(79,4,28,'2016-04-28 00:24:06',0),(80,5,28,'2016-04-28 00:24:13',0),(81,5,31,'2016-04-28 00:28:53',1),(82,6,28,'2016-04-28 00:29:03',1),(83,6,31,'2016-04-28 00:29:05',1),(84,6,28,'2016-04-28 00:31:21',0),(85,6,28,'2016-04-28 00:31:28',0),(86,6,1,'2016-04-28 01:08:43',1),(87,6,1,'2016-04-28 01:11:28',0),(88,6,4,'2016-04-28 01:22:13',1),(89,6,1,'2016-04-28 01:22:53',1),(90,6,4,'2016-04-28 01:23:03',0),(91,6,1,'2016-04-28 01:23:18',0),(92,4,2,'2016-04-28 01:23:43',1),(93,4,4,'2016-04-28 01:23:51',1),(94,4,1,'2016-04-28 01:24:11',1),(95,4,2,'2016-04-28 01:25:42',0),(96,4,1,'2016-04-28 01:44:02',0),(97,4,3,'2016-04-28 17:38:01',1),(98,3,2,'2016-04-28 17:38:05',1),(99,7,2,'2016-04-28 17:38:10',1),(100,7,15,'2016-04-28 17:38:14',1),(101,7,3,'2016-04-28 17:38:15',1),(102,3,2,'2016-04-28 17:43:10',0),(103,7,2,'2016-04-28 17:43:10',0),(104,4,3,'2016-04-28 17:44:10',0),(105,7,3,'2016-04-28 17:44:10',0),(106,1,1,'2016-04-28 22:42:16',1),(107,7,3,'2016-04-28 22:47:17',1),(108,7,3,'2016-04-28 22:47:47',0),(109,7,3,'2016-04-28 22:48:26',1),(110,7,3,'2016-04-28 22:48:56',0);
/*!40000 ALTER TABLE `groupJoins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `groupID` int(11) NOT NULL AUTO_INCREMENT,
  `groupName` varchar(50) DEFAULT NULL,
  `userID` int(11) DEFAULT NULL,
  `groupImage` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`groupID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES (1,'road aka aka AMF ',28,'3013.png'),(2,'acts six okay God ',28,'356924.png'),(3,'spent mark mag flag unseen if ',28,'1412369.png'),(4,'Chat App',31,'763983.png'),(5,'Technology ',31,'1100087.png'),(6,'Movies ',31,'1942097.png'),(7,'Friends',15,'x.png');
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `messageID` int(11) NOT NULL AUTO_INCREMENT,
  `groupID` int(11) DEFAULT NULL,
  `userID` int(11) DEFAULT NULL,
  `postTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `message` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`messageID`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (1,1,2,'2016-04-14 00:15:15','hello'),(2,1,28,'2016-04-14 00:22:00','Hi'),(3,1,28,'2016-04-14 00:28:57','I don\'t know '),(4,1,28,'2016-04-14 00:29:13','I don\'t know what to do for that matter of fact that I have '),(5,1,28,'2016-04-14 00:29:28','I don\'t know what to do for that matter of fact that I have have a great time to time and money to t the chat room for the next solo project I am a very good at it and I will always be a good time '),(6,1,31,'2016-04-14 06:59:06','hi'),(7,1,31,'2016-04-14 06:59:25','are u still awake'),(8,1,28,'2016-04-15 18:42:08','Kid '),(9,1,28,'2016-04-15 18:42:21','It works'),(10,1,31,'2016-04-15 18:44:32','Beta it works'),(11,4,31,'2016-04-15 18:44:38','hi'),(12,1,28,'2016-04-15 18:45:29','Yea I\'m getting notifications too'),(13,1,31,'2016-04-15 18:45:49','I still don\'t see notifications'),(14,1,28,'2016-04-15 18:46:02','Really'),(15,1,28,'2016-04-15 18:46:17','Even if you tab over to another app'),(16,1,32,'2016-04-15 18:46:23','yo'),(17,1,31,'2016-04-15 18:46:26','Yeah '),(18,1,32,'2016-04-15 18:46:31','wow'),(19,1,31,'2016-04-15 18:46:37','connect on to chat app group'),(20,1,31,'2016-04-15 18:46:44','it does not work kid'),(21,1,31,'2016-04-15 18:46:53','notifications.? '),(22,1,28,'2016-04-15 19:13:01','Sometimes it works for me other times it doesn\'t '),(23,4,28,'2016-04-18 23:07:45','I don\'t know what to do for that matter '),(24,4,31,'2016-04-18 23:07:47','hey'),(25,4,28,'2016-04-18 23:08:48','Ah '),(26,4,31,'2016-04-18 23:08:56','olol'),(27,4,31,'2016-04-18 23:08:59','dertykgcsdvb'),(28,4,31,'2016-04-18 23:09:01','gdf'),(29,4,31,'2016-04-18 23:09:34','tytytty'),(30,4,31,'2016-04-18 23:09:39','y'),(31,4,28,'2016-04-18 23:09:50','I y the '),(32,4,28,'2016-04-18 23:09:52','I don\'t know what to do for '),(33,3,28,'2016-04-18 23:55:05','ger'),(34,3,31,'2016-04-18 23:55:44','Hi'),(35,3,28,'2016-04-18 23:55:50','hi'),(36,4,31,'2016-04-19 00:08:39','hi'),(37,4,31,'2016-04-19 00:08:42','kiddo'),(38,3,31,'2016-04-19 00:08:50','kiddo'),(39,4,28,'2016-04-19 00:12:44','Did '),(40,1,28,'2016-04-20 18:21:46','Eh the chat room '),(41,1,28,'2016-04-20 18:21:50','I don\'t know what to '),(42,1,31,'2016-04-20 18:22:11','K'),(43,1,31,'2016-04-20 18:22:17','Go to the '),(44,3,28,'2016-04-20 18:39:50','I don\'t know what to do for that matter of fact '),(45,4,28,'2016-04-22 15:59:25','I don\'t know what to '),(46,4,31,'2016-04-22 16:00:41','hi'),(47,4,28,'2016-04-22 16:00:44','I don\'t know what to '),(48,4,31,'2016-04-22 16:00:49','oijoi'),(49,4,32,'2016-04-22 16:01:36','yo'),(50,4,28,'2016-04-22 16:01:45','Hi'),(51,4,31,'2016-04-22 16:01:49','whats up'),(52,4,32,'2016-04-22 16:02:04','lol'),(53,4,28,'2016-04-22 16:02:10','What lol'),(54,4,32,'2016-04-22 16:02:16','rofl'),(55,4,31,'2016-04-22 16:02:22','what rofl kid'),(56,4,32,'2016-04-22 16:02:43','I love my lunch'),(57,4,31,'2016-04-22 16:02:48','ok'),(58,4,31,'2016-04-22 16:03:45','hi'),(59,4,31,'2016-04-22 16:03:58','can u send few screen shots'),(60,4,31,'2016-04-22 16:04:14','of both phone and pc'),(61,4,32,'2016-04-22 16:04:26','I can\'t do screen shots on my phone'),(62,4,28,'2016-04-22 16:07:36','Hi '),(63,4,28,'2016-04-22 16:10:01','Let\'s have a real conversation first before I send screenshots'),(64,4,31,'2016-04-22 16:12:04','Okay'),(65,4,31,'2016-04-22 16:12:25','I am not getting notifications'),(66,4,31,'2016-04-22 16:13:57','really I am'),(67,4,31,'2016-04-22 16:14:20','do you not get them even if you go to a different app'),(68,4,28,'2016-04-22 16:16:39','What is that supposed to be'),(69,4,31,'2016-04-22 16:18:20','HAPPY Now'),(70,4,28,'2016-04-22 16:18:42','Happy about what kid '),(71,4,32,'2016-04-22 16:18:57','Thanks for. ......m.'),(72,4,28,'2016-04-22 16:19:27','What rude '),(73,4,31,'2016-04-22 16:21:05','nice drawing'),(74,4,31,'2016-04-22 16:21:22','Thanks'),(75,4,28,'2016-04-22 16:22:01','Kid why are you using my name '),(76,4,28,'2016-04-22 16:22:05','I\'m b'),(77,4,31,'2016-04-22 16:22:09','no i\'m b'),(78,4,32,'2016-04-22 16:22:44','added'),(79,4,32,'2016-04-22 16:22:57','sdfgf'),(80,4,31,'2016-04-22 16:23:09','I got notifications'),(81,4,31,'2016-04-22 16:23:20','but also got force closed'),(82,4,28,'2016-04-22 16:23:42','Man that\'s no good'),(83,4,28,'2016-04-22 16:23:50','We should present on my phone '),(84,4,32,'2016-04-22 16:23:52','good for you'),(85,4,31,'2016-04-22 16:24:03','Yeah good only for u'),(86,4,32,'2016-04-22 16:24:11','lol'),(87,4,32,'2016-04-22 16:24:27','I\'m crazy'),(88,4,32,'2016-04-22 16:24:32','I\'m lazy'),(89,4,31,'2016-04-22 16:24:44','so how at showing notifications like user joined, user left '),(90,4,31,'2016-04-22 16:25:31','also placeholder for the input text.'),(91,4,28,'2016-04-22 16:26:01','Man there are some minor bugs that I don\'t know hot to fix '),(92,4,31,'2016-04-22 16:26:21','like what'),(93,4,31,'2016-04-22 16:26:43','the app crashing randomly '),(94,4,31,'2016-04-22 16:27:27','Oh okay'),(95,4,31,'2016-04-22 16:28:12','are u using it on desktop'),(96,4,31,'2016-04-22 16:32:03','both desktop and android'),(97,4,31,'2016-04-22 16:32:07','no crashes on desktop so far'),(98,4,31,'2016-04-22 16:32:22','nice'),(99,4,31,'2016-04-22 16:32:22','rpi 3'),(100,4,31,'2016-04-22 16:32:31','oh wait i stopped getting messages on desktop'),(101,4,31,'2016-04-22 16:32:35','i can send them but i dont see them'),(102,4,28,'2016-04-22 16:33:06','Was that a pic'),(103,4,31,'2016-04-22 16:33:13','raspberry pi 3'),(104,4,28,'2016-04-22 16:33:30','But was it a pic '),(105,4,28,'2016-04-22 16:33:36','Because I couldn\'t see it'),(106,4,31,'2016-04-22 16:33:42','yes'),(107,4,28,'2016-04-22 16:33:56','Could you see it'),(108,4,31,'2016-04-22 16:34:01','yes'),(109,4,31,'2016-04-22 16:34:15','how about bala'),(110,4,28,'2016-04-22 16:34:16','Hm'),(111,4,28,'2016-04-22 16:34:49','He stopped getting messages too same time I did'),(112,4,31,'2016-04-22 16:34:56','whaat'),(113,4,31,'2016-04-22 16:35:34','Wait for an hour I will port all the things to new pi, and let\'s see If that\'s giving the trouble'),(114,4,28,'2016-04-22 16:35:46','K'),(115,4,31,'2016-04-22 22:26:26','hi'),(116,4,31,'2016-04-22 22:26:32','is it only me'),(117,4,31,'2016-04-22 22:26:35','out here'),(118,4,31,'2016-04-22 22:26:47','okay thats fine, i will leave now'),(119,4,31,'2016-04-22 22:26:50','bye'),(120,4,28,'2016-04-23 18:21:11','Hi'),(121,4,28,'2016-04-23 18:26:49','Nice'),(122,4,28,'2016-04-26 23:36:38','hi'),(123,4,37,'2016-04-26 23:36:44','Hey'),(124,4,28,'2016-04-26 23:44:02','hi'),(125,4,31,'2016-04-26 23:44:20','hey'),(126,4,31,'2016-04-28 00:07:53','hi'),(127,4,28,'2016-04-28 00:08:04','i\'m good how are you'),(128,4,31,'2016-04-28 00:08:10','how are you'),(129,6,31,'2016-04-28 00:29:24','I don\'t know what to '),(130,6,28,'2016-04-28 00:29:29','Hi how are you'),(131,6,31,'2016-04-28 00:29:33','Good thanks '),(132,4,2,'2016-04-28 01:23:54','yo Amish'),(133,4,1,'2016-04-28 01:24:23','Hey '),(134,4,4,'2016-04-28 01:24:31','whats up'),(135,4,2,'2016-04-28 01:24:34','futre vulnerability'),(136,4,2,'2016-04-28 01:24:42','futre vu'),(137,4,4,'2016-04-28 01:25:27','bonjour bala'),(138,7,2,'2016-04-28 17:38:15','hi'),(139,7,2,'2016-04-28 17:38:17','bala here'),(140,7,15,'2016-04-28 17:38:30','What are you doing Bala?'),(141,7,3,'2016-04-28 17:38:31','hey hi'),(142,7,2,'2016-04-28 17:38:39','hi bhargav'),(143,7,15,'2016-04-28 17:38:53','Oh, hi Bargav.  Why do we call you by your last name?'),(144,7,3,'2016-04-28 17:39:02','that\'s my first name'),(145,7,3,'2016-04-28 17:39:17','I got it changed on my passport'),(146,7,2,'2016-04-28 17:39:43','we\'re so excited to present tomorrow'),(147,7,3,'2016-04-28 22:48:40','hi'),(148,7,3,'2016-04-28 22:48:44','how is my art'),(149,7,3,'2016-04-28 22:48:53','okay fine');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registrationcodes`
--

DROP TABLE IF EXISTS `registrationcodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registrationcodes` (
  `codeID` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `code` int(11) DEFAULT NULL,
  PRIMARY KEY (`codeID`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registrationcodes`
--

LOCK TABLES `registrationcodes` WRITE;
/*!40000 ALTER TABLE `registrationcodes` DISABLE KEYS */;
INSERT INTO `registrationcodes` VALUES (20,'naikamish0822@gmail.com',5937),(21,'naikamish0822@gmail.com',9003),(22,'a@w.com',8047),(23,'aw@g',1573),(24,'e',7554),(25,'abc@gmail.com',4284),(26,'naikamish0822@gmail.com',5622),(27,'lkbhargav9@gmail.com',1636),(28,'lkbhargav9@gmail.com',3355),(29,'pratikkshah@hotmail.com',3523),(30,'naikamish0822@gmail.com',2542);
/*!40000 ALTER TABLE `registrationcodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sourcecodereq`
--

DROP TABLE IF EXISTS `sourcecodereq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sourcecodereq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `email` varchar(35) DEFAULT NULL,
  `contactNumber` bigint(20) DEFAULT NULL,
  `profession` varchar(25) DEFAULT NULL,
  `reason` varchar(300) DEFAULT NULL,
  `accepted` int(11) DEFAULT NULL,
  `denied` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sourcecodereq`
--

LOCK TABLES `sourcecodereq` WRITE;
/*!40000 ALTER TABLE `sourcecodereq` DISABLE KEYS */;
INSERT INTO `sourcecodereq` VALUES (1,'Bhargav L K','lkbhargav2@gmail.com',12035432147,'Student','Sai Baba it will work now.',1,0),(2,'abcd','madhur2k9@gmail.com',13392043986,'Student','test ',0,1),(3,'L K Bhargav','lkbhargav9@gmail.com',917259176285,'Student','I want this as reference for my final project',1,0),(4,'bala','madhur2k9@gmail.com',13392043986,'Student','please lemme download source code',1,0),(5,'asdfg','madhur2k9@gmail.com',13392043986,'Student','fjhgkj',0,1),(6,'Bhargav L K','lkbhargav2@gmail.com',12035432147,'Student','I want it ',0,1),(7,'Bhargav','lkbhargav9@gmail.com',12035432147,'Student','I like the way it works...',1,0),(8,'Sandra Adams','hondas@sacredheart.edu',12033717791,'Professor','ers',1,0);
/*!40000 ALTER TABLE `sourcecodereq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `userID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `salt` varchar(5000) DEFAULT NULL,
  `lname` varchar(20) DEFAULT NULL,
  `contactNumber` bigint(20) DEFAULT NULL,
  `activationCode` bigint(20) DEFAULT NULL,
  `activated` int(11) DEFAULT NULL,
  `imgName` varchar(40) DEFAULT NULL,
  `pwcr` int(11) DEFAULT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `lastLoginTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Amish','naikamish','a','naikamish0822@gmail.com',NULL,'Naik',12039135804,0,1,'naikamish',NULL,'2016-04-28 22:41:08','2016-04-28 22:41:08'),(2,'Bala','bala_yeruva','Passw0rd!','madhur2k9@gmail.com',NULL,'Yeruva',13392043986,0,1,'bala_yeruva.png',NULL,'2016-04-28 20:00:52','0000-00-00 00:00:00'),(3,'Bhargav','lkbhargav','Passw0rd!','lkbhargav9@gmail.com',NULL,'L K',12035432147,0,1,'lkbhargav.png',1,'2016-04-28 22:48:21','2016-04-28 22:48:21'),(4,'Amish','amish2','a','naika@mail.sacredheart.edu',NULL,'Naik',12039135804,0,1,'amish2.jpg',NULL,'2016-04-28 20:00:52','0000-00-00 00:00:00'),(5,'Bhargav','bhargavlk','Passw0rd!','lkbhargav5@gmail.com',NULL,'L K',12035432147,1257017396,0,NULL,NULL,'2016-04-28 20:00:52','0000-00-00 00:00:00'),(6,'Bhargav','bhargavl','Passw0rd!','lkbhargav2@gmail.com',NULL,'L K',12035432147,0,1,'bhargavl.jpg',NULL,'2016-04-28 20:00:52','0000-00-00 00:00:00'),(7,'Bhargav','bhargavlk2','Passw0rd!','lkbhargav8@gmail.com',NULL,'L K',12035432147,1184577580,0,'bhargavlk2.png',NULL,'2016-04-28 20:00:52','0000-00-00 00:00:00'),(14,'Bhargav','lkbhargav21','Passw0rd!','lkbhargav7@gmail.com',NULL,'L K',12035432147,0,1,NULL,NULL,'2016-04-28 20:00:52','0000-00-00 00:00:00'),(15,'Sandy','hondas','Passw0rd!','hondas@sacredheart.edu',NULL,'Honda',12033717791,0,1,'hondas.jpg',NULL,'2016-04-28 20:00:52','0000-00-00 00:00:00'),(16,'Mirza','Mirza111','Shujath@51','shujathullahmirza@gmail.com',NULL,'Shujathullah',12036838466,1378692210,0,NULL,NULL,'2016-04-28 20:00:52','0000-00-00 00:00:00'),(17,'Bhargav','lkbhargav10','Passw0rd!','lkbhargav10@gmail.com',NULL,'L K',12035432147,0,1,'lkbhargav10.jpg',NULL,'2016-04-28 22:28:36','2016-04-28 22:28:36');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-04-28 22:59:15
